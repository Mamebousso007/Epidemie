<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <th>Nom Zone :</th>
            <th>nombre personne syntome :</th>
            <th>nombre personne positif:</th>
         
        </tr>
        <?php 
            include_once "../model/Fonction.php";

            $edb = new Fonction();

            $Zone = $edb->getAllZone();

            foreach ($Zone as $zone) 
            {
                echo "<tr>
                        <td>$zone[1]</td>
                        <td>$zone[2]</td>
                        <td>$zone[3]</td>
                        
                    </tr>";
            }
        ?>
    </table>
</body>
</html>