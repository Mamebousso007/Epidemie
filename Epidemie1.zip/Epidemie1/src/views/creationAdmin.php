<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <style>
        form{
            background:gold;
            width: 500px;
            margin:auto;
            padding:80px;
        }
        button{
            margin-top:20px;
            width: 100px;
            text-align: center;
        }
    </style>
</head>
<body>
    <h1></h1>
    <form action="#" method="POST">
            <br>
            <div>
                <!-- <label for="">Bouton de creation de Pays</label>
                <input type="submit" value="pays"> -->
                <button><a href="addPersonne.php">Ajouter une Personne</a></button>

            </div>
        </form>
</body>
</html>