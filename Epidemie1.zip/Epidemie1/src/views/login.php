<?php
include_once "../model/Db.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Epidemie</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/style/css/style.css">
    <title>Document</title>
    <style>
    /*form{
            background-color: blue; 
            width: 500px;
        }*/
    </style>
</head>
<body>
    <center>
        <div class="main"  style="background-image:url('../Assets/Img/img5.jpg') ;height: 1000px;">
        <h1>Login </h1> 
       
       <!-- <br><br><br><br> -->
       <!-- <div style="background-color: grey; width: 500px;"> -->
       <br><br>
       <form action="#" method="POST">
           <br>
           <div>
               <label for="">username</label>
               <input type="text" name="username" required>
           </div>
           <br>
            <div>
               <label for="">password</label>
               <input type="text" name="password" required>
            </div>
            <br>
           <div>
           
               <input type="submit" value="Login">
           </div>
       </form>
           

       <!-- </div> -->
        </div>
        
    </center>
    
</body>
</html>