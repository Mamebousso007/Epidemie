<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            background-color: #f9f9f9;
            font-family: sans-serif;
        }

        form {
            margin: auto;
            max-width: 500px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        button {
            background-color: #ffa500;
            border: none;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 10px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        button:hover {
            background-color: #ff8c00;
        }

        a {
            color: #fff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="main"  style="background-image:url('../Assets/Img/img6.jpg') ;height: 1000px;">
>
    <h1>Menu principal</h1>
    <form action="#" method="POST">
        <div>
            <button><a href="addPays.php">Créer un Pays</a></button>
            <button><a href="addZone.php">Créer une Zone</a></button>
            <button><a href="addPoint.php">Créer un Point</a></button>
        </div>
    </form>
    </div>
</body>
</html>
