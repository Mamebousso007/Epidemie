<?php
    include_once "../model/Db.php";
    $db = new Db();
    $id = $_GET['idpoint'];
    $req = $db->query("DELETE FROM pointsurveiller WHERE idpoint = $id");
   // $req = mysqli_query($db, "DELETE FROM pays WHERE idpays = $id");
    if ($req) {
        header("Location: addPoint.php");
        exit();
    } else {
        echo "Une erreur est survenue lors de la suppression du pays.";
    }
    
   
?>
