<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pays Registration</title>
</head>
<body>
    <form action="http://localhost:8080/Epidemie1/src/controller/PaysController.php" method="post">
        <div>
            <label for="">Nom Pays : </label>
            <input type="text" name="nom"/>
        </div>
        <div>
            <label for="">PopulationTotal : </label>
            <input type="text" name="population" />
        </div>
        <div>
            <label for="">listeZone : </label>
            <input type="text" name="listezone"/>
        </div>
       
        <div>
            <input type="submit" name="submit" value="Register"/>
            <input type="reset" name="reset" value="Cancel"/>
        </div>
    </form>
</body>
</html>