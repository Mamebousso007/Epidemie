<?php
include_once "../model/Fonction.php";


$edb = new Fonction();
$zones = $edb->getAllZone();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zone Registration</title>
    <link rel="styleshoot" href="../Assets/Css/style.css ">
    <style>
                body{
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            position: relative;
        }
        .Btn_add{
            width: fit-content;
            margin-bottom: 10px;
            background-color: #2bc48a;
            padding: 5px 20px;
            color: #fff;
            display: flex;
            align-items: center;
            text-align: 0;
            border-radius: 6px;
            text-decoration: 0;
        }
        .Btn_add img{
            margin-right: 5px;
            height: 20px;
        }
        table{
            border-collapse: collapse;
            color: #404040;
        }
        th{
            font-size: 16px;
            border-bottom: 3px solid #ffcb61;
            padding: 5px 20px;
            font-weight: 500;

        }
        td{
            font-weight: 400;
            padding: 5px 30px;
            font-size: 14px;
        }
        img{
            height: 30px;
           
        }
        tr:nth-child(2n){
            background-color: 1px solid #e0e0e0;
            border-top: 1px solid #e0e0e0;
        }
    </style>
</head>
<body>
    <form action="#">
    <div class="container">
        <a href="ajouterZone.php" class="Btn_add"><img src="image.jpg">Ajouter</a>
        <table>
            <tr id="items">
                <th>Nom Zone</th>
                <th>Nombre Total</th>
                <th>nombre Personne Syntome</th>
                <th>nombre Personne Positive</th>
                <th>Modifier</th>
                <th>Supprimer</th>
            </tr>
            <!-- <?php foreach ($zones as $zone) { ?>
        <tr>
            <td><?= $zone['nom'] ?></td>
            <td><?= $zone['nombreTotal'] ?></td>
            <td><?= $zone['nombreps'] ?></td>
            <td><?= $zone['nombrepp'] ?></td>
            <td><a href='modifier.php?idzone=<?=$zone['idzone']?>'><img src='1752784.png'></a></td>
            <td><a href='supprimerZ.php?idzone=<?=$zone['idzone']?>'><img src='supprimer.png'></a></td>
        </tr>
        <?php } ?> -->
        <?php
            $sdb = new Fonction();
            $Zones = $sdb->selectAllZone();
            
            // $nbPositives = 0;
            // $populationTotal = count($Personnes);
            
            // foreach($Personnes as $personne){
            //     if($personne->getRésultat() == "positive"){
            //         $nbPositives++;
            //     }
            // }
            
           
            foreach($Zones as $zone => $value) {
                $taux = ($value->getNbrPersPositive() * 100) / $value->getNombreTotal();
                if ($taux < 5) {
                    $color = "#90EE90";
                } else if ($taux > 5 && $taux < 15) {
                    $color = "#FFA500";
                } else if ($taux > 15) {
                    $color = "#FF0000";
                }
                echo "<tr class='d-flex' style='background-color: $color'>";
                echo "<td class='col-md-1'>" . $value->getIdZone() . "</td>";
                echo "<td class='col-md-2'>" . $value->getNomZone() . "</td>";
                echo "<td class='col-md-1'>" . $value->getNombreTotal() . "</td>";
                echo "<td class='col-md-2'>" . $value->getNbrPersSynt() . "</td>";
                echo "<td class='col-md-2'>" . $value->getNbrPersPositive() . "</td>";
                echo "<td class='col-md-2'>
                      <a href='modifier.php?idzone={$value->getIdZone()}'><img src='1752784.png'></a>
                      <a href='supprimerZ.php?idzone={$value->getIdZone()}'><img src='supprimer.png'></a>
                      </td></tr>";
            }
            

        ?>
            <!-- <tr>
                <td>Senegal</td>
                <td>100</td>
                <td>zoneA</td>
                <td><a href="modifier.php"><img src="1752784.png"></a></td>
                <td><a href="#"><img src="supprimer.png"></a></td>
            </tr> -->
           
        </table>
    </div>
    </form>
   

</body>
</html>