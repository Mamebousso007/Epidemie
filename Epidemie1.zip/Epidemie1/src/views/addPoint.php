<?php
include_once "../model/Fonction.php";

$edb = new Fonction();
$points = $edb->getAllPoint();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zone Registration</title>
    <link rel="styleshoot" href="../Assets/Css/style.css ">
    <style>
                body{
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            position: relative;
        }
        .Btn_add{
            width: fit-content;
            margin-bottom: 10px;
            background-color: #2bc48a;
            padding: 5px 20px;
            color: #fff;
            display: flex;
            align-items: center;
            text-align: 0;
            border-radius: 6px;
            text-decoration: 0;
        }
        .Btn_add img{
            margin-right: 5px;
            height: 20px;
        }
        table{
            border-collapse: collapse;
            color: #404040;
        }
        th{
            font-size: 16px;
            border-bottom: 3px solid #ffcb61;
            padding: 5px 20px;
            font-weight: 500;

        }
        td{
            font-weight: 400;
            padding: 5px 30px;
            font-size: 14px;
        }
        img{
            height: 30px;
           
        }
        tr:nth-child(2n){
            background-color: 1px solid #e0e0e0;
            border-top: 1px solid #e0e0e0;
        }
    </style>
</head>
<body>
    <form action="#">
    <div class="container">
        <a href="ajouterPoint.php" class="Btn_add"><img src="image.jpg">Ajouter</a>
        <table>
            <tr id="items">
                <th>Nom Point</th>
                
                <th>Modifier</th>
                <th>Supprimer</th>
            </tr>
            <?php foreach ($points as $point) { ?>
        <tr>
            <td><?= $point['nom'] ?></td>
            <td><a href='modifier.php?idpoint=<?=$point['idpoint']?>'><img src='1752784.png'></a></td>
            <td><a href="supprimerP.php?idpoint=<?=$point['idpoint']?>"><img src='supprimer.png'></a></td>
        </tr>
        <?php } ?>
            <!-- <tr>
                <td>Senegal</td>
                <td>100</td>
                <td>zoneA</td>
                <td><a href="modifier.php"><img src="1752784.png"></a></td>
                <td><a href="#"><img src="supprimer.png"></a></td>
            </tr> -->
           
        </table>
    </div>
    </form>
   

</body>
</html>