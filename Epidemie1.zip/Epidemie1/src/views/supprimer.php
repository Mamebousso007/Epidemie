<?php
    include_once "../model/Db.php";
    $db = new Db();
    $id = $_GET['idpays'];
    $req = $db->query("DELETE FROM pays WHERE idpays = $id");
   // $req = mysqli_query($db, "DELETE FROM pays WHERE idpays = $id");
    if ($req) {
        header("Location: addPays.php");
        exit();
    } else {
        echo "Une erreur est survenue lors de la suppression du pays.";
    }
    
   
?>
