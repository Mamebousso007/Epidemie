<?php

include_once "../entities/Zone.php";
include_once "../model/Db.php";
include_once "../model/Fonction.php";


if(isset($_POST['submit']))
{
    extract($_POST);

    $zone = new Zone;

    $zone->setNomZone($_POST['nom']);
    $zone->setNombreTotal($_POST['nombreTotal']);
    $zone->setNbrPersSynt($_POST['nombreps']);
    $zone->setNbrPersPositive($_POST['nombrepp']);
 
    $sdb = new Fonction();

    $sdb->InsertZone($zone);

    header("location:http://localhost/Epidemie1/src/views/addZone.php");

}