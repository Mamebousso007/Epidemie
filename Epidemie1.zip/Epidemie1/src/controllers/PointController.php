<?php

include_once "../entities/PointSur.php";
include_once "../model/Db.php";
include_once "../model/Fonction.php";


if(isset($_POST['submit']))
{
    extract($_POST);

    $point = new PointSurv;

    $point->setNomPointS($_POST['nom']);
   
    $sdb = new Fonction();

    $sdb->insertPoint($point);

    header("location:http://localhost/Epidemie1/src/views/addPoint.php");

}