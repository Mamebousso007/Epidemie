<?php

include_once "../entities/Personne.php";
include_once "../entities/Pays.php";
include_once "../model/Db.php";
include_once "../model/Fonction.php";
// $nbSymptôme = 0; 
// $nbPositive = 0;
// $nbNégative = 0;
// $cpt=0;

// $population = isset($_POST['population']) ;
// $nbPositives = 0;
$sdb = new Fonction();
$Personnes = $sdb->selectAllPersonne();

$nbPositives = 0;
$populationTotal = count($Personnes);

foreach($Personnes as $personne){
    if($personne->getRésultat() == "positive"){
        $nbPositives++;
    }
}


$percentage = ($nbPositives / $populationTotal) * 100;

echo "Le nombre de personnes positives est: " . $nbPositives;
echo "Le nombre de personnes total est: " . $populationTotal;
echo "Le pourcentage de personnes positif est: " . $percentage."%";
if(isset($_POST['submit']))
{
    extract($_POST);

    $personne = new Personne;

    $personne->setNomP($_POST['nom']);
    $personne->setPrenomP($_POST['prenom']);
    $personne->setNumTel($_POST['numero']);
    $personne->setAdresse($_POST['address']);
    $personne->setSexe($_POST['sexe']);
    $personne->setRésultat($_POST['resultat']);

    
// if(isset($_POST['submit']))
// {
//     $nbPositives++;
// }

// $percentage = ($nbPositives / $population) * 100;

// if($percentage < 5) {
//     $bgColor = "green";
// } elseif($percentage >= 5 && $percentage < 15) {
//     $bgColor = "orange";
// } else {
//     $bgColor = "red";
// }


    // if ($_POST['résultat']== "positive"){
    //    $cpt+= 1;
    // }
    // if ($_POST['résultat']== "négative"){
    //     $nbNégative++;
    // }
    // if ($_POST['résultat']== "symptômatique"){
    //     $nbSymptôme++;
    // }
 
    $sdb = new Fonction();

    $sdb->InsertPersonne($personne);

    header("location:http://localhost/Epidemie1/src/views/addPersonne.php");
//     echo $cpt;
//     echo $nbNégative;
//     echo $nbSymptôme;
}