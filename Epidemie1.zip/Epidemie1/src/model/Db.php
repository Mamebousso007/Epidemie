<?php
class Db {
    protected $host = "localhost";
    protected $user = "root";
    protected $password = "";
    protected $db = "users";
    protected $conn;

    public function __construct() {
        $this->conn = mysqli_connect($this->host, $this->user, $this->password, $this->db);
        if ($this->conn === false) {
            die("Connection error");
        }
    }

    public function query($sql) {
        return mysqli_query($this->conn, $sql);
    }

    public function fetchArray($result) {
        return mysqli_fetch_array($result);
    }
}

class Login {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function authenticate($username, $password) {
        $sql = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";
        $result = $this->db->query($sql);
        $row = $this->db->fetchArray($result);

        if ($row["usertype"] == "users") {
            $_SESSION["username"] = $username;
            header("location:http://localhost/Epidemie1/src/views/creation.php");
        } elseif ($row["usertype"] == "admin") {
            $_SESSION["username"] = $username;
            header("location:http://localhost/Epidemie1/src/views/creationAdmin.php");
        } else {
            echo "Username or password incorrect";
        }
    }
}

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];

        $db = new Db();
        $login = new Login($db);
        $login->authenticate($username, $password);
    } else {
        echo "Please enter both username and password";
    }
}
?>