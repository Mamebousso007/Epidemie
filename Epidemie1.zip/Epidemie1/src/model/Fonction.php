<?php
include_once "Db.php";
include_once "../entities/Zone.php";

class Fonction extends Db
{
    public function __construct()
    {
        parent::__construct();
    }

    public function insertPays($pays)
    {
        $sql = "INSERT INTO pays VALUES(NULL, '".$pays->getNomPays()."', '".$pays->getPopulationTotal()."', '".$pays->getListeZone()."')";
        return $this->query($sql);
    }
    public function InsertZone($zone)
    {
        $sql = "INSERT INTO zones VALUES(NULL, '".$zone->getNomZone()."',
                                                '".$zone->getNombreTotal()."',
                                              '".$zone->getNbrPersSynt()."',
                                              '".$zone->getNbrPersPositive()."')";
       return $this->query($sql);
      // return $this->db->exec($sql);
    }
    

    public function InsertPoint($point)
    {
        $sql = "INSERT INTO pointsurveiller VALUES(NULL, '".$point->getNomPointS()."')";
        return $this->query($sql);
    }
    public function getAllPays()
    {
        $sql = "SELECT * FROM pays";

        return $this->conn->query($sql);
    }

    // public function update(Pays $pays){
    //     $sql = "UPDATE pays SET nom = '".$pays->getNomPays()."', '".$pays->getPopulationTotal()."', '".$pays->getListeZone()."' 
    //     WHERE idpays = ".$pays->getIdPays()"";
    //     $dbs = $conn->exec($sql);
    //     return $dbs;
    // }

    public function getAllZone()
    {
        $sql = "SELECT * FROM zones ";
        return $this->conn->query($sql);

        //return $this->db->query($sql);
    }
    public function getAllPoint()
    {
        $sql = "SELECT * FROM pointsurveiller ";
        return $this->conn->query($sql);


    }
    public function InsertPersonne($personne){
        
        $sql = "INSERT INTO personne VALUES(NULL,'".$personne->getNomP()."','".$personne->getPrenomP()."','".$personne->getNumTel()."','".$personne->getAdresse()."','".$personne->getSexe()."','".$personne->getRésultat()."')";

        return $this->query($sql);
    }
    public function GetAllPersonne()
    {
        $sql = "SELECT * FROM personne";
        return $this->conn->query($sql);
    }
    public function selectAllPersonne(){
        $db = new Db();
    
        $sql = "SELECT * FROM personne";
        $result = $db->query($sql);
    
        $personnes = array();
        while($row = mysqli_fetch_assoc($result)){
            $personne = new Personne();
            $personne->setIdPersonne($row['idpersonne']);
            $personne->setNomP($row['nom']);
            $personne->setPrenomP($row['prenom']);
            $personne->setNumTel($row['numero']);
            $personne->setAdresse($row['address']);
            $personne->setSexe($row['sexe']);
            $personne->setRésultat($row['resultat']);
    
            $personnes[] = $personne;
        }
        return $personnes;
    }

    public function selectAllZone(){
        $db = new Db();
    
        $sql = "SELECT * FROM zones";
        $result = $db->query($sql);
    
        $zones = array();
        while($row = mysqli_fetch_assoc($result)){
            $zone = new Zone();
            $zone->setIdZone($row['idzone']);
            $zone->setNomZone($row['nom']);
            $zone->setNombreTotal($row['nombreTotal']);
            $zone->setNbrPersSynt($row['nombreps']);
            $zone->setNbrPersPositive($row['nombrepp']);
           
    
            $zones[] = $zone;
        }
        return $zones;
    }
    
    
    

    
   
}